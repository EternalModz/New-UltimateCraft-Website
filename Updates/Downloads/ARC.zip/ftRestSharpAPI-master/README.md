# ftRestSharpAPI

A sample GUI using Rest API calls and responses to display live soccer scores, league tables, fixtures and top scorers in a slick borderless Windows Form Application.

API calls and response deserialisation is found in ftRestSharpAPI\ftAppForm.cs.

API Keys have been removed for security, please feel free to enter your own in ftRestSharpAPI\ftAppForm.cs.

Contact me at D00234161@student.dkit.ie for support, queries or requests.
