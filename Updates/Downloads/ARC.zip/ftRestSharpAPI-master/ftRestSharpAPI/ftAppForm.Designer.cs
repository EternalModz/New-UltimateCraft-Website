﻿
namespace ftRestSharpAPI
{
    partial class ftAppForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ftAppForm));
            this.controlPanel = new System.Windows.Forms.Panel();
            this.premierLeagueButton = new System.Windows.Forms.Button();
            this.ligue1Button = new System.Windows.Forms.Button();
            this.serieAButton = new System.Windows.Forms.Button();
            this.logoPictureBox2 = new System.Windows.Forms.PictureBox();
            this.logoPictureBox1 = new System.Windows.Forms.PictureBox();
            this.laLigaButton = new System.Windows.Forms.Button();
            this.bundesligaButton = new System.Windows.Forms.Button();
            this.championsLeagueButton = new System.Windows.Forms.Button();
            this.toolbarPanel = new System.Windows.Forms.Panel();
            this.fixturesButton = new System.Windows.Forms.Button();
            this.scoresButton = new System.Windows.Forms.Button();
            this.minimiseButton = new System.Windows.Forms.Button();
            this.topScorerButton = new System.Windows.Forms.Button();
            this.refreshButton = new System.Windows.Forms.Button();
            this.closeButton = new System.Windows.Forms.Button();
            this.leagueTableListview = new System.Windows.Forms.ListView();
            this.LeagueTableListViewColumnPos = new System.Windows.Forms.ColumnHeader();
            this.LeagueTableListViewColumnTeam = new System.Windows.Forms.ColumnHeader();
            this.LeagueTableListViewColumnPlayed = new System.Windows.Forms.ColumnHeader();
            this.LeagueTableListViewColumnWon = new System.Windows.Forms.ColumnHeader();
            this.LeagueTableListViewColumnDrawn = new System.Windows.Forms.ColumnHeader();
            this.LeagueTableListViewColumnLost = new System.Windows.Forms.ColumnHeader();
            this.LeagueTableListViewColumnFor = new System.Windows.Forms.ColumnHeader();
            this.LeagueTableListViewColumnAgainst = new System.Windows.Forms.ColumnHeader();
            this.LeagueTableListViewColumnGD = new System.Windows.Forms.ColumnHeader();
            this.LeagueTableListViewColumnPoints = new System.Windows.Forms.ColumnHeader();
            this.topScorerListView = new System.Windows.Forms.ListView();
            this.topScorerListViewColumnPlayer = new System.Windows.Forms.ColumnHeader();
            this.topScorerListViewColumnGoals = new System.Windows.Forms.ColumnHeader();
            this.topScorerListViewColumnTeam = new System.Windows.Forms.ColumnHeader();
            this.topScorerPictureBox = new System.Windows.Forms.PictureBox();
            this.topScorerNameLabel = new System.Windows.Forms.Label();
            this.topScorerGoalsLabel = new System.Windows.Forms.Label();
            this.listViewGroupD = new System.Windows.Forms.ListView();
            this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader2 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader3 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader4 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader5 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader6 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader7 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader8 = new System.Windows.Forms.ColumnHeader();
            this.listViewGroupB = new System.Windows.Forms.ListView();
            this.columnHeader9 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader10 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader11 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader12 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader13 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader14 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader15 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader16 = new System.Windows.Forms.ColumnHeader();
            this.listViewGroupC = new System.Windows.Forms.ListView();
            this.columnHeader17 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader18 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader19 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader20 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader21 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader22 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader23 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader24 = new System.Windows.Forms.ColumnHeader();
            this.listViewGroupH = new System.Windows.Forms.ListView();
            this.columnHeader25 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader26 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader27 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader28 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader29 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader30 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader31 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader32 = new System.Windows.Forms.ColumnHeader();
            this.listViewGroupG = new System.Windows.Forms.ListView();
            this.columnHeader33 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader34 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader35 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader36 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader37 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader38 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader39 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader40 = new System.Windows.Forms.ColumnHeader();
            this.listViewGroupF = new System.Windows.Forms.ListView();
            this.columnHeader41 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader42 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader43 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader44 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader45 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader46 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader47 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader48 = new System.Windows.Forms.ColumnHeader();
            this.listViewGroupE = new System.Windows.Forms.ListView();
            this.columnHeader49 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader50 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader51 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader52 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader53 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader54 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader55 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader56 = new System.Windows.Forms.ColumnHeader();
            this.listViewGroupA = new System.Windows.Forms.ListView();
            this.columnHeader57 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader58 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader59 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader60 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader61 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader62 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader63 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader64 = new System.Windows.Forms.ColumnHeader();
            this.groupALabel = new System.Windows.Forms.Label();
            this.groupBLabel = new System.Windows.Forms.Label();
            this.groupCLabel = new System.Windows.Forms.Label();
            this.groupDLabel = new System.Windows.Forms.Label();
            this.groupHLabel = new System.Windows.Forms.Label();
            this.groupGLabel = new System.Windows.Forms.Label();
            this.groupFLabel = new System.Windows.Forms.Label();
            this.groupELabel = new System.Windows.Forms.Label();
            this.welcomePictureBox = new System.Windows.Forms.PictureBox();
            this.welcomePictureBox2 = new System.Windows.Forms.PictureBox();
            this.fixturesListView = new System.Windows.Forms.ListView();
            this.columnHeader65 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader66 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader67 = new System.Windows.Forms.ColumnHeader();
            this.columnHeader68 = new System.Windows.Forms.ColumnHeader();
            this.fixturesLabel = new System.Windows.Forms.Label();
            this.resultsLabel = new System.Windows.Forms.Label();
            this.controlPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.logoPictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.logoPictureBox1)).BeginInit();
            this.toolbarPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.topScorerPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.welcomePictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.welcomePictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // controlPanel
            // 
            this.controlPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(19)))), ((int)(((byte)(62)))));
            this.controlPanel.Controls.Add(this.premierLeagueButton);
            this.controlPanel.Controls.Add(this.ligue1Button);
            this.controlPanel.Controls.Add(this.serieAButton);
            this.controlPanel.Controls.Add(this.logoPictureBox2);
            this.controlPanel.Controls.Add(this.logoPictureBox1);
            this.controlPanel.Controls.Add(this.laLigaButton);
            this.controlPanel.Controls.Add(this.bundesligaButton);
            this.controlPanel.Controls.Add(this.championsLeagueButton);
            this.controlPanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.controlPanel.Location = new System.Drawing.Point(0, 0);
            this.controlPanel.Name = "controlPanel";
            this.controlPanel.Size = new System.Drawing.Size(270, 727);
            this.controlPanel.TabIndex = 0;
            // 
            // premierLeagueButton
            // 
            this.premierLeagueButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(19)))), ((int)(((byte)(62)))));
            this.premierLeagueButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.premierLeagueButton.FlatAppearance.BorderSize = 0;
            this.premierLeagueButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.premierLeagueButton.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.premierLeagueButton.ForeColor = System.Drawing.Color.White;
            this.premierLeagueButton.Image = ((System.Drawing.Image)(resources.GetObject("premierLeagueButton.Image")));
            this.premierLeagueButton.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.premierLeagueButton.Location = new System.Drawing.Point(1, 140);
            this.premierLeagueButton.Name = "premierLeagueButton";
            this.premierLeagueButton.Size = new System.Drawing.Size(269, 94);
            this.premierLeagueButton.TabIndex = 8;
            this.premierLeagueButton.Text = " Premier League";
            this.premierLeagueButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.premierLeagueButton.UseVisualStyleBackColor = false;
            this.premierLeagueButton.Click += new System.EventHandler(this.premierLeagueButton_Click);
            // 
            // ligue1Button
            // 
            this.ligue1Button.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(19)))), ((int)(((byte)(62)))));
            this.ligue1Button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ligue1Button.FlatAppearance.BorderSize = 0;
            this.ligue1Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ligue1Button.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ligue1Button.ForeColor = System.Drawing.Color.White;
            this.ligue1Button.Image = ((System.Drawing.Image)(resources.GetObject("ligue1Button.Image")));
            this.ligue1Button.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ligue1Button.Location = new System.Drawing.Point(1, 540);
            this.ligue1Button.Name = "ligue1Button";
            this.ligue1Button.Size = new System.Drawing.Size(269, 94);
            this.ligue1Button.TabIndex = 7;
            this.ligue1Button.Text = "  Ligue 1";
            this.ligue1Button.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.ligue1Button.UseVisualStyleBackColor = false;
            this.ligue1Button.Click += new System.EventHandler(this.ligue1Button_Click);
            // 
            // serieAButton
            // 
            this.serieAButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(19)))), ((int)(((byte)(62)))));
            this.serieAButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.serieAButton.FlatAppearance.BorderSize = 0;
            this.serieAButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.serieAButton.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.serieAButton.ForeColor = System.Drawing.Color.White;
            this.serieAButton.Image = ((System.Drawing.Image)(resources.GetObject("serieAButton.Image")));
            this.serieAButton.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.serieAButton.Location = new System.Drawing.Point(1, 440);
            this.serieAButton.Name = "serieAButton";
            this.serieAButton.Size = new System.Drawing.Size(269, 94);
            this.serieAButton.TabIndex = 6;
            this.serieAButton.Text = "  Serie A";
            this.serieAButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.serieAButton.UseVisualStyleBackColor = false;
            this.serieAButton.Click += new System.EventHandler(this.serieAButton_Click);
            // 
            // logoPictureBox2
            // 
            this.logoPictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("logoPictureBox2.Image")));
            this.logoPictureBox2.Location = new System.Drawing.Point(160, 50);
            this.logoPictureBox2.Name = "logoPictureBox2";
            this.logoPictureBox2.Size = new System.Drawing.Size(65, 76);
            this.logoPictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.logoPictureBox2.TabIndex = 5;
            this.logoPictureBox2.TabStop = false;
            // 
            // logoPictureBox1
            // 
            this.logoPictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("logoPictureBox1.Image")));
            this.logoPictureBox1.Location = new System.Drawing.Point(36, 12);
            this.logoPictureBox1.Name = "logoPictureBox1";
            this.logoPictureBox1.Size = new System.Drawing.Size(152, 144);
            this.logoPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.logoPictureBox1.TabIndex = 4;
            this.logoPictureBox1.TabStop = false;
            // 
            // laLigaButton
            // 
            this.laLigaButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(19)))), ((int)(((byte)(62)))));
            this.laLigaButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.laLigaButton.FlatAppearance.BorderSize = 0;
            this.laLigaButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.laLigaButton.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.laLigaButton.ForeColor = System.Drawing.Color.White;
            this.laLigaButton.Image = ((System.Drawing.Image)(resources.GetObject("laLigaButton.Image")));
            this.laLigaButton.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.laLigaButton.Location = new System.Drawing.Point(1, 340);
            this.laLigaButton.Name = "laLigaButton";
            this.laLigaButton.Size = new System.Drawing.Size(269, 94);
            this.laLigaButton.TabIndex = 3;
            this.laLigaButton.Text = "  La Liga";
            this.laLigaButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.laLigaButton.UseVisualStyleBackColor = false;
            this.laLigaButton.Click += new System.EventHandler(this.laLigaButton_Click);
            // 
            // bundesligaButton
            // 
            this.bundesligaButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(19)))), ((int)(((byte)(62)))));
            this.bundesligaButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bundesligaButton.FlatAppearance.BorderSize = 0;
            this.bundesligaButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bundesligaButton.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.bundesligaButton.ForeColor = System.Drawing.Color.White;
            this.bundesligaButton.Image = ((System.Drawing.Image)(resources.GetObject("bundesligaButton.Image")));
            this.bundesligaButton.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bundesligaButton.Location = new System.Drawing.Point(1, 240);
            this.bundesligaButton.Name = "bundesligaButton";
            this.bundesligaButton.Size = new System.Drawing.Size(269, 94);
            this.bundesligaButton.TabIndex = 2;
            this.bundesligaButton.Text = " Bundesliga";
            this.bundesligaButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.bundesligaButton.UseVisualStyleBackColor = false;
            this.bundesligaButton.Click += new System.EventHandler(this.bundesligaButton_Click);
            // 
            // championsLeagueButton
            // 
            this.championsLeagueButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(19)))), ((int)(((byte)(62)))));
            this.championsLeagueButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.championsLeagueButton.FlatAppearance.BorderSize = 0;
            this.championsLeagueButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.championsLeagueButton.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.championsLeagueButton.ForeColor = System.Drawing.Color.White;
            this.championsLeagueButton.Image = ((System.Drawing.Image)(resources.GetObject("championsLeagueButton.Image")));
            this.championsLeagueButton.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.championsLeagueButton.Location = new System.Drawing.Point(1, 630);
            this.championsLeagueButton.Name = "championsLeagueButton";
            this.championsLeagueButton.Padding = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.championsLeagueButton.Size = new System.Drawing.Size(269, 97);
            this.championsLeagueButton.TabIndex = 1;
            this.championsLeagueButton.Text = "Champions League";
            this.championsLeagueButton.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.championsLeagueButton.UseVisualStyleBackColor = false;
            this.championsLeagueButton.Click += new System.EventHandler(this.championsLeagueButton_Click);
            // 
            // toolbarPanel
            // 
            this.toolbarPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(19)))), ((int)(((byte)(62)))));
            this.toolbarPanel.Controls.Add(this.fixturesButton);
            this.toolbarPanel.Controls.Add(this.scoresButton);
            this.toolbarPanel.Controls.Add(this.minimiseButton);
            this.toolbarPanel.Controls.Add(this.topScorerButton);
            this.toolbarPanel.Controls.Add(this.refreshButton);
            this.toolbarPanel.Controls.Add(this.closeButton);
            this.toolbarPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.toolbarPanel.Location = new System.Drawing.Point(270, 0);
            this.toolbarPanel.Name = "toolbarPanel";
            this.toolbarPanel.Size = new System.Drawing.Size(1160, 50);
            this.toolbarPanel.TabIndex = 1;
            // 
            // fixturesButton
            // 
            this.fixturesButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(19)))), ((int)(((byte)(62)))));
            this.fixturesButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.fixturesButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.fixturesButton.FlatAppearance.BorderSize = 0;
            this.fixturesButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.fixturesButton.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.fixturesButton.ForeColor = System.Drawing.Color.White;
            this.fixturesButton.Image = ((System.Drawing.Image)(resources.GetObject("fixturesButton.Image")));
            this.fixturesButton.Location = new System.Drawing.Point(154, 2);
            this.fixturesButton.Name = "fixturesButton";
            this.fixturesButton.Size = new System.Drawing.Size(68, 49);
            this.fixturesButton.TabIndex = 11;
            this.fixturesButton.UseVisualStyleBackColor = false;
            this.fixturesButton.Visible = false;
            this.fixturesButton.Click += new System.EventHandler(this.fixturesButton_Click);
            // 
            // scoresButton
            // 
            this.scoresButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(19)))), ((int)(((byte)(62)))));
            this.scoresButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.scoresButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.scoresButton.FlatAppearance.BorderSize = 0;
            this.scoresButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.scoresButton.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.scoresButton.ForeColor = System.Drawing.Color.White;
            this.scoresButton.Image = ((System.Drawing.Image)(resources.GetObject("scoresButton.Image")));
            this.scoresButton.Location = new System.Drawing.Point(80, 2);
            this.scoresButton.Name = "scoresButton";
            this.scoresButton.Size = new System.Drawing.Size(68, 49);
            this.scoresButton.TabIndex = 10;
            this.scoresButton.UseVisualStyleBackColor = false;
            this.scoresButton.Visible = false;
            this.scoresButton.Click += new System.EventHandler(this.scoresButton_Click);
            // 
            // minimiseButton
            // 
            this.minimiseButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(19)))), ((int)(((byte)(62)))));
            this.minimiseButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.minimiseButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.minimiseButton.FlatAppearance.BorderSize = 0;
            this.minimiseButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.minimiseButton.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.minimiseButton.ForeColor = System.Drawing.Color.White;
            this.minimiseButton.Image = ((System.Drawing.Image)(resources.GetObject("minimiseButton.Image")));
            this.minimiseButton.Location = new System.Drawing.Point(963, 1);
            this.minimiseButton.Name = "minimiseButton";
            this.minimiseButton.Size = new System.Drawing.Size(68, 49);
            this.minimiseButton.TabIndex = 9;
            this.minimiseButton.UseVisualStyleBackColor = false;
            this.minimiseButton.Click += new System.EventHandler(this.minimiseButton_Click);
            // 
            // topScorerButton
            // 
            this.topScorerButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(19)))), ((int)(((byte)(62)))));
            this.topScorerButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.topScorerButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.topScorerButton.FlatAppearance.BorderSize = 0;
            this.topScorerButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.topScorerButton.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.topScorerButton.ForeColor = System.Drawing.Color.White;
            this.topScorerButton.Image = ((System.Drawing.Image)(resources.GetObject("topScorerButton.Image")));
            this.topScorerButton.Location = new System.Drawing.Point(6, 1);
            this.topScorerButton.Name = "topScorerButton";
            this.topScorerButton.Size = new System.Drawing.Size(68, 49);
            this.topScorerButton.TabIndex = 8;
            this.topScorerButton.UseVisualStyleBackColor = false;
            this.topScorerButton.Visible = false;
            this.topScorerButton.Click += new System.EventHandler(this.topScorerButton_Click);
            // 
            // refreshButton
            // 
            this.refreshButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(19)))), ((int)(((byte)(62)))));
            this.refreshButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.refreshButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.refreshButton.FlatAppearance.BorderSize = 0;
            this.refreshButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.refreshButton.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.refreshButton.ForeColor = System.Drawing.Color.White;
            this.refreshButton.Image = ((System.Drawing.Image)(resources.GetObject("refreshButton.Image")));
            this.refreshButton.Location = new System.Drawing.Point(1028, 1);
            this.refreshButton.Name = "refreshButton";
            this.refreshButton.Size = new System.Drawing.Size(68, 49);
            this.refreshButton.TabIndex = 7;
            this.refreshButton.UseVisualStyleBackColor = false;
            this.refreshButton.Click += new System.EventHandler(this.refreshButton_Click);
            // 
            // closeButton
            // 
            this.closeButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(19)))), ((int)(((byte)(19)))), ((int)(((byte)(62)))));
            this.closeButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.closeButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.closeButton.FlatAppearance.BorderSize = 0;
            this.closeButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.closeButton.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.closeButton.ForeColor = System.Drawing.Color.White;
            this.closeButton.Image = ((System.Drawing.Image)(resources.GetObject("closeButton.Image")));
            this.closeButton.Location = new System.Drawing.Point(1093, 1);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(68, 49);
            this.closeButton.TabIndex = 6;
            this.closeButton.UseVisualStyleBackColor = false;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // leagueTableListview
            // 
            this.leagueTableListview.BackColor = System.Drawing.SystemColors.Window;
            this.leagueTableListview.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.leagueTableListview.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.LeagueTableListViewColumnPos,
            this.LeagueTableListViewColumnTeam,
            this.LeagueTableListViewColumnPlayed,
            this.LeagueTableListViewColumnWon,
            this.LeagueTableListViewColumnDrawn,
            this.LeagueTableListViewColumnLost,
            this.LeagueTableListViewColumnFor,
            this.LeagueTableListViewColumnAgainst,
            this.LeagueTableListViewColumnGD,
            this.LeagueTableListViewColumnPoints});
            this.leagueTableListview.Dock = System.Windows.Forms.DockStyle.Right;
            this.leagueTableListview.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.leagueTableListview.FullRowSelect = true;
            this.leagueTableListview.GridLines = true;
            this.leagueTableListview.HideSelection = false;
            this.leagueTableListview.Location = new System.Drawing.Point(270, 50);
            this.leagueTableListview.Name = "leagueTableListview";
            this.leagueTableListview.Size = new System.Drawing.Size(1160, 677);
            this.leagueTableListview.TabIndex = 7;
            this.leagueTableListview.UseCompatibleStateImageBehavior = false;
            this.leagueTableListview.View = System.Windows.Forms.View.Details;
            this.leagueTableListview.Visible = false;
            // 
            // LeagueTableListViewColumnPos
            // 
            this.LeagueTableListViewColumnPos.Text = "Pos";
            this.LeagueTableListViewColumnPos.Width = 75;
            // 
            // LeagueTableListViewColumnTeam
            // 
            this.LeagueTableListViewColumnTeam.Text = "Team";
            this.LeagueTableListViewColumnTeam.Width = 278;
            // 
            // LeagueTableListViewColumnPlayed
            // 
            this.LeagueTableListViewColumnPlayed.Text = "Played";
            this.LeagueTableListViewColumnPlayed.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.LeagueTableListViewColumnPlayed.Width = 100;
            // 
            // LeagueTableListViewColumnWon
            // 
            this.LeagueTableListViewColumnWon.Text = "Won";
            this.LeagueTableListViewColumnWon.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.LeagueTableListViewColumnWon.Width = 100;
            // 
            // LeagueTableListViewColumnDrawn
            // 
            this.LeagueTableListViewColumnDrawn.Text = "Drawn";
            this.LeagueTableListViewColumnDrawn.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.LeagueTableListViewColumnDrawn.Width = 100;
            // 
            // LeagueTableListViewColumnLost
            // 
            this.LeagueTableListViewColumnLost.Text = "Lost";
            this.LeagueTableListViewColumnLost.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.LeagueTableListViewColumnLost.Width = 100;
            // 
            // LeagueTableListViewColumnFor
            // 
            this.LeagueTableListViewColumnFor.Text = "For";
            this.LeagueTableListViewColumnFor.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.LeagueTableListViewColumnFor.Width = 100;
            // 
            // LeagueTableListViewColumnAgainst
            // 
            this.LeagueTableListViewColumnAgainst.Text = "Against";
            this.LeagueTableListViewColumnAgainst.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.LeagueTableListViewColumnAgainst.Width = 103;
            // 
            // LeagueTableListViewColumnGD
            // 
            this.LeagueTableListViewColumnGD.Text = "GD";
            this.LeagueTableListViewColumnGD.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.LeagueTableListViewColumnGD.Width = 100;
            // 
            // LeagueTableListViewColumnPoints
            // 
            this.LeagueTableListViewColumnPoints.Text = "Points";
            this.LeagueTableListViewColumnPoints.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.LeagueTableListViewColumnPoints.Width = 100;
            // 
            // topScorerListView
            // 
            this.topScorerListView.BackColor = System.Drawing.SystemColors.Window;
            this.topScorerListView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.topScorerListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.topScorerListViewColumnPlayer,
            this.topScorerListViewColumnGoals,
            this.topScorerListViewColumnTeam});
            this.topScorerListView.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.topScorerListView.FullRowSelect = true;
            this.topScorerListView.GridLines = true;
            this.topScorerListView.HideSelection = false;
            this.topScorerListView.Location = new System.Drawing.Point(302, 50);
            this.topScorerListView.Name = "topScorerListView";
            this.topScorerListView.Size = new System.Drawing.Size(870, 677);
            this.topScorerListView.TabIndex = 10;
            this.topScorerListView.UseCompatibleStateImageBehavior = false;
            this.topScorerListView.View = System.Windows.Forms.View.Details;
            this.topScorerListView.Visible = false;
            // 
            // topScorerListViewColumnPlayer
            // 
            this.topScorerListViewColumnPlayer.Text = "Player";
            this.topScorerListViewColumnPlayer.Width = 370;
            // 
            // topScorerListViewColumnGoals
            // 
            this.topScorerListViewColumnGoals.Text = "Goals";
            this.topScorerListViewColumnGoals.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.topScorerListViewColumnGoals.Width = 130;
            // 
            // topScorerListViewColumnTeam
            // 
            this.topScorerListViewColumnTeam.Text = "Team";
            this.topScorerListViewColumnTeam.Width = 370;
            // 
            // topScorerPictureBox
            // 
            this.topScorerPictureBox.Location = new System.Drawing.Point(1196, 103);
            this.topScorerPictureBox.Name = "topScorerPictureBox";
            this.topScorerPictureBox.Size = new System.Drawing.Size(170, 170);
            this.topScorerPictureBox.TabIndex = 11;
            this.topScorerPictureBox.TabStop = false;
            this.topScorerPictureBox.Visible = false;
            // 
            // topScorerNameLabel
            // 
            this.topScorerNameLabel.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.topScorerNameLabel.Location = new System.Drawing.Point(1196, 276);
            this.topScorerNameLabel.Name = "topScorerNameLabel";
            this.topScorerNameLabel.Size = new System.Drawing.Size(170, 67);
            this.topScorerNameLabel.TabIndex = 12;
            this.topScorerNameLabel.Text = "topGoalscorerNameLabel";
            this.topScorerNameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.topScorerNameLabel.Visible = false;
            // 
            // topScorerGoalsLabel
            // 
            this.topScorerGoalsLabel.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.topScorerGoalsLabel.Location = new System.Drawing.Point(1196, 336);
            this.topScorerGoalsLabel.Name = "topScorerGoalsLabel";
            this.topScorerGoalsLabel.Size = new System.Drawing.Size(170, 38);
            this.topScorerGoalsLabel.TabIndex = 13;
            this.topScorerGoalsLabel.Text = "topGoalscorerGoalsLabel";
            this.topScorerGoalsLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.topScorerGoalsLabel.Visible = false;
            // 
            // listViewGroupD
            // 
            this.listViewGroupD.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listViewGroupD.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8});
            this.listViewGroupD.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.listViewGroupD.FullRowSelect = true;
            this.listViewGroupD.GridLines = true;
            this.listViewGroupD.HideSelection = false;
            this.listViewGroupD.Location = new System.Drawing.Point(403, 549);
            this.listViewGroupD.Name = "listViewGroupD";
            this.listViewGroupD.Size = new System.Drawing.Size(417, 175);
            this.listViewGroupD.TabIndex = 15;
            this.listViewGroupD.UseCompatibleStateImageBehavior = false;
            this.listViewGroupD.View = System.Windows.Forms.View.Details;
            this.listViewGroupD.Visible = false;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "";
            this.columnHeader1.Width = 19;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Team";
            this.columnHeader2.Width = 180;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "P";
            this.columnHeader3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader3.Width = 30;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "W";
            this.columnHeader4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader4.Width = 30;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "D";
            this.columnHeader5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader5.Width = 30;
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "L";
            this.columnHeader6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader6.Width = 30;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "GD";
            this.columnHeader7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader7.Width = 45;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Pts";
            this.columnHeader8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader8.Width = 40;
            // 
            // listViewGroupB
            // 
            this.listViewGroupB.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listViewGroupB.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader9,
            this.columnHeader10,
            this.columnHeader11,
            this.columnHeader12,
            this.columnHeader13,
            this.columnHeader14,
            this.columnHeader15,
            this.columnHeader16});
            this.listViewGroupB.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.listViewGroupB.FullRowSelect = true;
            this.listViewGroupB.GridLines = true;
            this.listViewGroupB.HideSelection = false;
            this.listViewGroupB.Location = new System.Drawing.Point(403, 221);
            this.listViewGroupB.Name = "listViewGroupB";
            this.listViewGroupB.Size = new System.Drawing.Size(417, 166);
            this.listViewGroupB.TabIndex = 16;
            this.listViewGroupB.UseCompatibleStateImageBehavior = false;
            this.listViewGroupB.View = System.Windows.Forms.View.Details;
            this.listViewGroupB.Visible = false;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "";
            this.columnHeader9.Width = 19;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Team";
            this.columnHeader10.Width = 180;
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "P";
            this.columnHeader11.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader11.Width = 30;
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "W";
            this.columnHeader12.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader12.Width = 30;
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "D";
            this.columnHeader13.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader13.Width = 30;
            // 
            // columnHeader14
            // 
            this.columnHeader14.Text = "L";
            this.columnHeader14.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader14.Width = 30;
            // 
            // columnHeader15
            // 
            this.columnHeader15.Text = "GD";
            this.columnHeader15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader15.Width = 45;
            // 
            // columnHeader16
            // 
            this.columnHeader16.Text = "Pts";
            this.columnHeader16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader16.Width = 40;
            // 
            // listViewGroupC
            // 
            this.listViewGroupC.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listViewGroupC.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader17,
            this.columnHeader18,
            this.columnHeader19,
            this.columnHeader20,
            this.columnHeader21,
            this.columnHeader22,
            this.columnHeader23,
            this.columnHeader24});
            this.listViewGroupC.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.listViewGroupC.FullRowSelect = true;
            this.listViewGroupC.GridLines = true;
            this.listViewGroupC.HideSelection = false;
            this.listViewGroupC.Location = new System.Drawing.Point(403, 384);
            this.listViewGroupC.Name = "listViewGroupC";
            this.listViewGroupC.Size = new System.Drawing.Size(417, 159);
            this.listViewGroupC.TabIndex = 17;
            this.listViewGroupC.UseCompatibleStateImageBehavior = false;
            this.listViewGroupC.View = System.Windows.Forms.View.Details;
            this.listViewGroupC.Visible = false;
            // 
            // columnHeader17
            // 
            this.columnHeader17.Text = "";
            this.columnHeader17.Width = 19;
            // 
            // columnHeader18
            // 
            this.columnHeader18.Text = "Team";
            this.columnHeader18.Width = 180;
            // 
            // columnHeader19
            // 
            this.columnHeader19.Text = "P";
            this.columnHeader19.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader19.Width = 30;
            // 
            // columnHeader20
            // 
            this.columnHeader20.Text = "W";
            this.columnHeader20.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader20.Width = 30;
            // 
            // columnHeader21
            // 
            this.columnHeader21.Text = "D";
            this.columnHeader21.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader21.Width = 30;
            // 
            // columnHeader22
            // 
            this.columnHeader22.Text = "L";
            this.columnHeader22.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader22.Width = 30;
            // 
            // columnHeader23
            // 
            this.columnHeader23.Text = "GD";
            this.columnHeader23.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader23.Width = 45;
            // 
            // columnHeader24
            // 
            this.columnHeader24.Text = "Pts";
            this.columnHeader24.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader24.Width = 40;
            // 
            // listViewGroupH
            // 
            this.listViewGroupH.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listViewGroupH.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader25,
            this.columnHeader26,
            this.columnHeader27,
            this.columnHeader28,
            this.columnHeader29,
            this.columnHeader30,
            this.columnHeader31,
            this.columnHeader32});
            this.listViewGroupH.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.listViewGroupH.FullRowSelect = true;
            this.listViewGroupH.GridLines = true;
            this.listViewGroupH.HideSelection = false;
            this.listViewGroupH.Location = new System.Drawing.Point(941, 549);
            this.listViewGroupH.Name = "listViewGroupH";
            this.listViewGroupH.Size = new System.Drawing.Size(417, 175);
            this.listViewGroupH.TabIndex = 19;
            this.listViewGroupH.UseCompatibleStateImageBehavior = false;
            this.listViewGroupH.View = System.Windows.Forms.View.Details;
            this.listViewGroupH.Visible = false;
            // 
            // columnHeader25
            // 
            this.columnHeader25.Text = "";
            this.columnHeader25.Width = 19;
            // 
            // columnHeader26
            // 
            this.columnHeader26.Text = "Team";
            this.columnHeader26.Width = 180;
            // 
            // columnHeader27
            // 
            this.columnHeader27.Text = "P";
            this.columnHeader27.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader27.Width = 30;
            // 
            // columnHeader28
            // 
            this.columnHeader28.Text = "W";
            this.columnHeader28.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader28.Width = 30;
            // 
            // columnHeader29
            // 
            this.columnHeader29.Text = "D";
            this.columnHeader29.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader29.Width = 30;
            // 
            // columnHeader30
            // 
            this.columnHeader30.Text = "L";
            this.columnHeader30.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader30.Width = 30;
            // 
            // columnHeader31
            // 
            this.columnHeader31.Text = "GD";
            this.columnHeader31.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader31.Width = 45;
            // 
            // columnHeader32
            // 
            this.columnHeader32.Text = "Pts";
            this.columnHeader32.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader32.Width = 40;
            // 
            // listViewGroupG
            // 
            this.listViewGroupG.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listViewGroupG.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader33,
            this.columnHeader34,
            this.columnHeader35,
            this.columnHeader36,
            this.columnHeader37,
            this.columnHeader38,
            this.columnHeader39,
            this.columnHeader40});
            this.listViewGroupG.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.listViewGroupG.FullRowSelect = true;
            this.listViewGroupG.GridLines = true;
            this.listViewGroupG.HideSelection = false;
            this.listViewGroupG.Location = new System.Drawing.Point(941, 384);
            this.listViewGroupG.Name = "listViewGroupG";
            this.listViewGroupG.Size = new System.Drawing.Size(417, 159);
            this.listViewGroupG.TabIndex = 21;
            this.listViewGroupG.UseCompatibleStateImageBehavior = false;
            this.listViewGroupG.View = System.Windows.Forms.View.Details;
            this.listViewGroupG.Visible = false;
            // 
            // columnHeader33
            // 
            this.columnHeader33.Text = "";
            this.columnHeader33.Width = 19;
            // 
            // columnHeader34
            // 
            this.columnHeader34.Text = "Team";
            this.columnHeader34.Width = 180;
            // 
            // columnHeader35
            // 
            this.columnHeader35.Text = "P";
            this.columnHeader35.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader35.Width = 30;
            // 
            // columnHeader36
            // 
            this.columnHeader36.Text = "W";
            this.columnHeader36.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader36.Width = 30;
            // 
            // columnHeader37
            // 
            this.columnHeader37.Text = "D";
            this.columnHeader37.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader37.Width = 30;
            // 
            // columnHeader38
            // 
            this.columnHeader38.Text = "L";
            this.columnHeader38.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader38.Width = 30;
            // 
            // columnHeader39
            // 
            this.columnHeader39.Text = "GD";
            this.columnHeader39.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader39.Width = 45;
            // 
            // columnHeader40
            // 
            this.columnHeader40.Text = "Pts";
            this.columnHeader40.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader40.Width = 40;
            // 
            // listViewGroupF
            // 
            this.listViewGroupF.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listViewGroupF.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader41,
            this.columnHeader42,
            this.columnHeader43,
            this.columnHeader44,
            this.columnHeader45,
            this.columnHeader46,
            this.columnHeader47,
            this.columnHeader48});
            this.listViewGroupF.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.listViewGroupF.FullRowSelect = true;
            this.listViewGroupF.GridLines = true;
            this.listViewGroupF.HideSelection = false;
            this.listViewGroupF.Location = new System.Drawing.Point(941, 221);
            this.listViewGroupF.Name = "listViewGroupF";
            this.listViewGroupF.Size = new System.Drawing.Size(417, 166);
            this.listViewGroupF.TabIndex = 20;
            this.listViewGroupF.UseCompatibleStateImageBehavior = false;
            this.listViewGroupF.View = System.Windows.Forms.View.Details;
            this.listViewGroupF.Visible = false;
            // 
            // columnHeader41
            // 
            this.columnHeader41.Text = "";
            this.columnHeader41.Width = 19;
            // 
            // columnHeader42
            // 
            this.columnHeader42.Text = "Team";
            this.columnHeader42.Width = 180;
            // 
            // columnHeader43
            // 
            this.columnHeader43.Text = "P";
            this.columnHeader43.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader43.Width = 30;
            // 
            // columnHeader44
            // 
            this.columnHeader44.Text = "W";
            this.columnHeader44.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader44.Width = 30;
            // 
            // columnHeader45
            // 
            this.columnHeader45.Text = "D";
            this.columnHeader45.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader45.Width = 30;
            // 
            // columnHeader46
            // 
            this.columnHeader46.Text = "L";
            this.columnHeader46.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader46.Width = 30;
            // 
            // columnHeader47
            // 
            this.columnHeader47.Text = "GD";
            this.columnHeader47.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader47.Width = 45;
            // 
            // columnHeader48
            // 
            this.columnHeader48.Text = "Pts";
            this.columnHeader48.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader48.Width = 40;
            // 
            // listViewGroupE
            // 
            this.listViewGroupE.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listViewGroupE.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader49,
            this.columnHeader50,
            this.columnHeader51,
            this.columnHeader52,
            this.columnHeader53,
            this.columnHeader54,
            this.columnHeader55,
            this.columnHeader56});
            this.listViewGroupE.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.listViewGroupE.FullRowSelect = true;
            this.listViewGroupE.GridLines = true;
            this.listViewGroupE.HideSelection = false;
            this.listViewGroupE.Location = new System.Drawing.Point(941, 50);
            this.listViewGroupE.Name = "listViewGroupE";
            this.listViewGroupE.Size = new System.Drawing.Size(417, 170);
            this.listViewGroupE.TabIndex = 18;
            this.listViewGroupE.UseCompatibleStateImageBehavior = false;
            this.listViewGroupE.View = System.Windows.Forms.View.Details;
            this.listViewGroupE.Visible = false;
            // 
            // columnHeader49
            // 
            this.columnHeader49.Text = "";
            this.columnHeader49.Width = 19;
            // 
            // columnHeader50
            // 
            this.columnHeader50.Text = "Team";
            this.columnHeader50.Width = 180;
            // 
            // columnHeader51
            // 
            this.columnHeader51.Text = "P";
            this.columnHeader51.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader51.Width = 30;
            // 
            // columnHeader52
            // 
            this.columnHeader52.Text = "W";
            this.columnHeader52.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader52.Width = 30;
            // 
            // columnHeader53
            // 
            this.columnHeader53.Text = "D";
            this.columnHeader53.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader53.Width = 30;
            // 
            // columnHeader54
            // 
            this.columnHeader54.Text = "L";
            this.columnHeader54.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader54.Width = 30;
            // 
            // columnHeader55
            // 
            this.columnHeader55.Text = "GD";
            this.columnHeader55.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader55.Width = 45;
            // 
            // columnHeader56
            // 
            this.columnHeader56.Text = "Pts";
            this.columnHeader56.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader56.Width = 40;
            // 
            // listViewGroupA
            // 
            this.listViewGroupA.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listViewGroupA.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader57,
            this.columnHeader58,
            this.columnHeader59,
            this.columnHeader60,
            this.columnHeader61,
            this.columnHeader62,
            this.columnHeader63,
            this.columnHeader64});
            this.listViewGroupA.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.listViewGroupA.FullRowSelect = true;
            this.listViewGroupA.GridLines = true;
            this.listViewGroupA.HideSelection = false;
            this.listViewGroupA.Location = new System.Drawing.Point(403, 50);
            this.listViewGroupA.Name = "listViewGroupA";
            this.listViewGroupA.Size = new System.Drawing.Size(417, 175);
            this.listViewGroupA.TabIndex = 22;
            this.listViewGroupA.UseCompatibleStateImageBehavior = false;
            this.listViewGroupA.View = System.Windows.Forms.View.Details;
            this.listViewGroupA.Visible = false;
            // 
            // columnHeader57
            // 
            this.columnHeader57.Text = "";
            this.columnHeader57.Width = 19;
            // 
            // columnHeader58
            // 
            this.columnHeader58.Text = "Team";
            this.columnHeader58.Width = 180;
            // 
            // columnHeader59
            // 
            this.columnHeader59.Text = "P";
            this.columnHeader59.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader59.Width = 30;
            // 
            // columnHeader60
            // 
            this.columnHeader60.Text = "W";
            this.columnHeader60.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader60.Width = 30;
            // 
            // columnHeader61
            // 
            this.columnHeader61.Text = "D";
            this.columnHeader61.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader61.Width = 30;
            // 
            // columnHeader62
            // 
            this.columnHeader62.Text = "L";
            this.columnHeader62.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader62.Width = 30;
            // 
            // columnHeader63
            // 
            this.columnHeader63.Text = "GD";
            this.columnHeader63.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader63.Width = 45;
            // 
            // columnHeader64
            // 
            this.columnHeader64.Text = "Pts";
            this.columnHeader64.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader64.Width = 40;
            // 
            // groupALabel
            // 
            this.groupALabel.AutoSize = true;
            this.groupALabel.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.groupALabel.Location = new System.Drawing.Point(311, 54);
            this.groupALabel.Name = "groupALabel";
            this.groupALabel.Size = new System.Drawing.Size(91, 21);
            this.groupALabel.TabIndex = 9;
            this.groupALabel.Text = "Group A:";
            this.groupALabel.Visible = false;
            // 
            // groupBLabel
            // 
            this.groupBLabel.AutoSize = true;
            this.groupBLabel.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.groupBLabel.Location = new System.Drawing.Point(311, 225);
            this.groupBLabel.Name = "groupBLabel";
            this.groupBLabel.Size = new System.Drawing.Size(86, 21);
            this.groupBLabel.TabIndex = 23;
            this.groupBLabel.Text = "Group B:";
            this.groupBLabel.Visible = false;
            // 
            // groupCLabel
            // 
            this.groupCLabel.AutoSize = true;
            this.groupCLabel.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.groupCLabel.Location = new System.Drawing.Point(311, 389);
            this.groupCLabel.Name = "groupCLabel";
            this.groupCLabel.Size = new System.Drawing.Size(91, 21);
            this.groupCLabel.TabIndex = 24;
            this.groupCLabel.Text = "Group C:";
            this.groupCLabel.Visible = false;
            // 
            // groupDLabel
            // 
            this.groupDLabel.AutoSize = true;
            this.groupDLabel.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.groupDLabel.Location = new System.Drawing.Point(311, 554);
            this.groupDLabel.Name = "groupDLabel";
            this.groupDLabel.Size = new System.Drawing.Size(89, 21);
            this.groupDLabel.TabIndex = 25;
            this.groupDLabel.Text = "Group D:";
            this.groupDLabel.Visible = false;
            // 
            // groupHLabel
            // 
            this.groupHLabel.AutoSize = true;
            this.groupHLabel.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.groupHLabel.Location = new System.Drawing.Point(853, 554);
            this.groupHLabel.Name = "groupHLabel";
            this.groupHLabel.Size = new System.Drawing.Size(88, 21);
            this.groupHLabel.TabIndex = 29;
            this.groupHLabel.Text = "Group H:";
            this.groupHLabel.Visible = false;
            // 
            // groupGLabel
            // 
            this.groupGLabel.AutoSize = true;
            this.groupGLabel.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.groupGLabel.Location = new System.Drawing.Point(853, 389);
            this.groupGLabel.Name = "groupGLabel";
            this.groupGLabel.Size = new System.Drawing.Size(92, 21);
            this.groupGLabel.TabIndex = 28;
            this.groupGLabel.Text = "Group G:";
            this.groupGLabel.Visible = false;
            // 
            // groupFLabel
            // 
            this.groupFLabel.AutoSize = true;
            this.groupFLabel.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.groupFLabel.Location = new System.Drawing.Point(853, 225);
            this.groupFLabel.Name = "groupFLabel";
            this.groupFLabel.Size = new System.Drawing.Size(85, 21);
            this.groupFLabel.TabIndex = 27;
            this.groupFLabel.Text = "Group F:";
            this.groupFLabel.Visible = false;
            // 
            // groupELabel
            // 
            this.groupELabel.AutoSize = true;
            this.groupELabel.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.groupELabel.Location = new System.Drawing.Point(853, 54);
            this.groupELabel.Name = "groupELabel";
            this.groupELabel.Size = new System.Drawing.Size(86, 21);
            this.groupELabel.TabIndex = 26;
            this.groupELabel.Text = "Group E:";
            this.groupELabel.Visible = false;
            // 
            // welcomePictureBox
            // 
            this.welcomePictureBox.Image = ((System.Drawing.Image)(resources.GetObject("welcomePictureBox.Image")));
            this.welcomePictureBox.Location = new System.Drawing.Point(507, 140);
            this.welcomePictureBox.Name = "welcomePictureBox";
            this.welcomePictureBox.Size = new System.Drawing.Size(628, 85);
            this.welcomePictureBox.TabIndex = 9;
            this.welcomePictureBox.TabStop = false;
            // 
            // welcomePictureBox2
            // 
            this.welcomePictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("welcomePictureBox2.Image")));
            this.welcomePictureBox2.Location = new System.Drawing.Point(661, 362);
            this.welcomePictureBox2.Name = "welcomePictureBox2";
            this.welcomePictureBox2.Size = new System.Drawing.Size(350, 25);
            this.welcomePictureBox2.TabIndex = 10;
            this.welcomePictureBox2.TabStop = false;
            // 
            // fixturesListView
            // 
            this.fixturesListView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.fixturesListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader65,
            this.columnHeader66,
            this.columnHeader67,
            this.columnHeader68});
            this.fixturesListView.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.fixturesListView.FullRowSelect = true;
            this.fixturesListView.HideSelection = false;
            this.fixturesListView.Location = new System.Drawing.Point(332, 103);
            this.fixturesListView.Name = "fixturesListView";
            this.fixturesListView.Size = new System.Drawing.Size(1086, 578);
            this.fixturesListView.TabIndex = 11;
            this.fixturesListView.UseCompatibleStateImageBehavior = false;
            this.fixturesListView.View = System.Windows.Forms.View.Details;
            this.fixturesListView.Visible = false;
            // 
            // columnHeader65
            // 
            this.columnHeader65.Text = "";
            this.columnHeader65.Width = 400;
            // 
            // columnHeader66
            // 
            this.columnHeader66.Text = "";
            this.columnHeader66.Width = 90;
            // 
            // columnHeader67
            // 
            this.columnHeader67.Text = "";
            this.columnHeader67.Width = 400;
            // 
            // columnHeader68
            // 
            this.columnHeader68.Text = "";
            this.columnHeader68.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader68.Width = 150;
            // 
            // fixturesLabel
            // 
            this.fixturesLabel.AutoSize = true;
            this.fixturesLabel.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point);
            this.fixturesLabel.Location = new System.Drawing.Point(300, 70);
            this.fixturesLabel.Name = "fixturesLabel";
            this.fixturesLabel.Size = new System.Drawing.Size(390, 34);
            this.fixturesLabel.TabIndex = 30;
            this.fixturesLabel.Text = "Champions League Fixtures";
            this.fixturesLabel.Visible = false;
            // 
            // resultsLabel
            // 
            this.resultsLabel.AutoSize = true;
            this.resultsLabel.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point);
            this.resultsLabel.Location = new System.Drawing.Point(300, 70);
            this.resultsLabel.Name = "resultsLabel";
            this.resultsLabel.Size = new System.Drawing.Size(382, 34);
            this.resultsLabel.TabIndex = 31;
            this.resultsLabel.Text = "Champions League Results";
            this.resultsLabel.Visible = false;
            // 
            // ftAppForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(1430, 727);
            this.Controls.Add(this.welcomePictureBox2);
            this.Controls.Add(this.welcomePictureBox);
            this.Controls.Add(this.leagueTableListview);
            this.Controls.Add(this.resultsLabel);
            this.Controls.Add(this.fixturesLabel);
            this.Controls.Add(this.toolbarPanel);
            this.Controls.Add(this.groupFLabel);
            this.Controls.Add(this.controlPanel);
            this.Controls.Add(this.listViewGroupA);
            this.Controls.Add(this.topScorerListView);
            this.Controls.Add(this.fixturesListView);
            this.Controls.Add(this.groupALabel);
            this.Controls.Add(this.groupBLabel);
            this.Controls.Add(this.listViewGroupB);
            this.Controls.Add(this.listViewGroupC);
            this.Controls.Add(this.groupCLabel);
            this.Controls.Add(this.groupDLabel);
            this.Controls.Add(this.listViewGroupD);
            this.Controls.Add(this.groupGLabel);
            this.Controls.Add(this.listViewGroupG);
            this.Controls.Add(this.listViewGroupF);
            this.Controls.Add(this.listViewGroupE);
            this.Controls.Add(this.groupELabel);
            this.Controls.Add(this.topScorerPictureBox);
            this.Controls.Add(this.topScorerNameLabel);
            this.Controls.Add(this.topScorerGoalsLabel);
            this.Controls.Add(this.listViewGroupH);
            this.Controls.Add(this.groupHLabel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ftAppForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "APIBenSamEmmet";
            this.controlPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.logoPictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.logoPictureBox1)).EndInit();
            this.toolbarPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.topScorerPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.welcomePictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.welcomePictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel controlPanel;
        private System.Windows.Forms.Panel toolbarPanel;
        private System.Windows.Forms.Button championsLeagueButton;
        private System.Windows.Forms.Button bundesligaButton;
        private System.Windows.Forms.Button closeButton;
        private System.Windows.Forms.ColumnHeader LeagueTableListViewColumnPos;
        //private System.Windows.Forms.ColumnHeader Team;
        //private System.Windows.Forms.ColumnHeader Played;
        //private System.Windows.Forms.ColumnHeader Won;
        //private System.Windows.Forms.ColumnHeader Drawn;
        //private System.Windows.Forms.ColumnHeader Lost;
        //private System.Windows.Forms.ColumnHeader For;
        //private System.Windows.Forms.ColumnHeader Against;
        //private System.Windows.Forms.ColumnHeader GD;
        //private System.Windows.Forms.ColumnHeader Points;
        private System.Windows.Forms.Button laLigaButton;
        private System.Windows.Forms.PictureBox logoPictureBox1;
        private System.Windows.Forms.PictureBox logoPictureBox2;
        private System.Windows.Forms.Button serieAButton;
        private System.Windows.Forms.Button ligue1Button;
        private System.Windows.Forms.ListView leagueTableListview;
        private System.Windows.Forms.Button refreshButton;
        private System.Windows.Forms.Button topScorerButton;
        private System.Windows.Forms.Button premierLeagueButton;
        private System.Windows.Forms.Button minimiseButton;
        private System.Windows.Forms.ListView topScorerListView;
        private System.Windows.Forms.ColumnHeader topScorerListViewColumnPlayer;
        private System.Windows.Forms.ColumnHeader topScorerListViewColumnGoals;
        private System.Windows.Forms.ColumnHeader topScorerListViewColumnTeam;
        private System.Windows.Forms.PictureBox topScorerPictureBox;
        private System.Windows.Forms.ColumnHeader LeagueTableListViewColumnTeam;
        private System.Windows.Forms.ColumnHeader LeagueTableListViewColumnPlayed;
        private System.Windows.Forms.ColumnHeader LeagueTableListViewColumnWon;
        private System.Windows.Forms.ColumnHeader LeagueTableListViewColumnDrawn;
        private System.Windows.Forms.ColumnHeader LeagueTableListViewColumnLost;
        private System.Windows.Forms.ColumnHeader LeagueTableListViewColumnFor;
        private System.Windows.Forms.ColumnHeader LeagueTableListViewColumnAgainst;
        private System.Windows.Forms.ColumnHeader LeagueTableListViewColumnGD;
        private System.Windows.Forms.ColumnHeader LeagueTableListViewColumnPoints;
        private System.Windows.Forms.Label topScorerNameLabel;
        private System.Windows.Forms.Label topScorerGoalsLabel;
        private System.Windows.Forms.ListView listViewGroupD;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ListView listViewGroupB;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.ColumnHeader columnHeader13;
        private System.Windows.Forms.ColumnHeader columnHeader14;
        private System.Windows.Forms.ColumnHeader columnHeader15;
        private System.Windows.Forms.ColumnHeader columnHeader16;
        private System.Windows.Forms.ListView listViewGroupC;
        private System.Windows.Forms.ColumnHeader columnHeader17;
        private System.Windows.Forms.ColumnHeader columnHeader18;
        private System.Windows.Forms.ColumnHeader columnHeader19;
        private System.Windows.Forms.ColumnHeader columnHeader20;
        private System.Windows.Forms.ColumnHeader columnHeader21;
        private System.Windows.Forms.ColumnHeader columnHeader22;
        private System.Windows.Forms.ColumnHeader columnHeader23;
        private System.Windows.Forms.ColumnHeader columnHeader24;
        private System.Windows.Forms.ColumnHeader columnHeader25;
        private System.Windows.Forms.ColumnHeader columnHeader26;
        private System.Windows.Forms.ColumnHeader columnHeader27;
        private System.Windows.Forms.ColumnHeader columnHeader28;
        private System.Windows.Forms.ColumnHeader columnHeader29;
        private System.Windows.Forms.ColumnHeader columnHeader30;
        private System.Windows.Forms.ColumnHeader columnHeader31;
        private System.Windows.Forms.ColumnHeader columnHeader32;
        private System.Windows.Forms.ListView listViewGroupG;
        private System.Windows.Forms.ColumnHeader columnHeader33;
        private System.Windows.Forms.ColumnHeader columnHeader34;
        private System.Windows.Forms.ColumnHeader columnHeader35;
        private System.Windows.Forms.ColumnHeader columnHeader36;
        private System.Windows.Forms.ColumnHeader columnHeader37;
        private System.Windows.Forms.ColumnHeader columnHeader38;
        private System.Windows.Forms.ColumnHeader columnHeader39;
        private System.Windows.Forms.ColumnHeader columnHeader40;
        private System.Windows.Forms.ListView listViewGroupF;
        private System.Windows.Forms.ColumnHeader columnHeader41;
        private System.Windows.Forms.ColumnHeader columnHeader42;
        private System.Windows.Forms.ColumnHeader columnHeader43;
        private System.Windows.Forms.ColumnHeader columnHeader44;
        private System.Windows.Forms.ColumnHeader columnHeader45;
        private System.Windows.Forms.ColumnHeader columnHeader46;
        private System.Windows.Forms.ColumnHeader columnHeader47;
        private System.Windows.Forms.ColumnHeader columnHeader48;
        private System.Windows.Forms.ListView listViewGroupE;
        private System.Windows.Forms.ColumnHeader columnHeader49;
        private System.Windows.Forms.ColumnHeader columnHeader50;
        private System.Windows.Forms.ColumnHeader columnHeader51;
        private System.Windows.Forms.ColumnHeader columnHeader52;
        private System.Windows.Forms.ColumnHeader columnHeader53;
        private System.Windows.Forms.ColumnHeader columnHeader54;
        private System.Windows.Forms.ColumnHeader columnHeader55;
        private System.Windows.Forms.ColumnHeader columnHeader56;
        private System.Windows.Forms.ListView listViewGroupH;
        private System.Windows.Forms.ListView listViewGroupA;
        private System.Windows.Forms.ColumnHeader columnHeader57;
        private System.Windows.Forms.ColumnHeader columnHeader58;
        private System.Windows.Forms.ColumnHeader columnHeader59;
        private System.Windows.Forms.ColumnHeader columnHeader60;
        private System.Windows.Forms.ColumnHeader columnHeader61;
        private System.Windows.Forms.ColumnHeader columnHeader62;
        private System.Windows.Forms.ColumnHeader columnHeader63;
        private System.Windows.Forms.ColumnHeader columnHeader64;
        private System.Windows.Forms.Label groupALabel;
        private System.Windows.Forms.Label groupBLabel;
        private System.Windows.Forms.Label groupCLabel;
        private System.Windows.Forms.Label groupDLabel;
        private System.Windows.Forms.Label groupHLabel;
        private System.Windows.Forms.Label groupGLabel;
        private System.Windows.Forms.Label groupFLabel;
        private System.Windows.Forms.Label groupELabel;
        private System.Windows.Forms.PictureBox welcomePictureBox;
        private System.Windows.Forms.PictureBox welcomePictureBox2;
        private System.Windows.Forms.Button scoresButton;
        private System.Windows.Forms.ListView fixturesListView;
        private System.Windows.Forms.ColumnHeader columnHeader65;
        private System.Windows.Forms.ColumnHeader columnHeader66;
        private System.Windows.Forms.ColumnHeader columnHeader67;
        private System.Windows.Forms.ColumnHeader columnHeader68;
        private System.Windows.Forms.Button fixturesButton;
        private System.Windows.Forms.Label fixturesLabel;
        private System.Windows.Forms.Label resultsLabel;
    }
}

