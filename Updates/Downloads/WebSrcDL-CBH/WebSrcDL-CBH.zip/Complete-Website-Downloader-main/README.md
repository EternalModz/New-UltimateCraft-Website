[![CodeFactor](https://www.codefactor.io/repository/github/badrshs/complete-website-downloader/badge)](https://www.codefactor.io/repository/github/badrshs/complete-website-downloader)
[![GitHub release](https://img.shields.io/github/release/badrshs/Complete-Website-Downloader.svg?logo=github)](https://github.com/badrshs/Complete-Website-Downloader/releases/latest)


## Complete Website Downloader 💾
Download the complete source code of any website (including all assets) 🔨.

![image](https://user-images.githubusercontent.com/26596347/136267623-26aa15a2-0520-4900-93ca-1e50e803d20d.png)

## Description 📒
 Website downloader works with `wget` to download all websites assets to your pc 
  ## Direct Download
 - [Download](https://github.com/badrshs/Complete-Website-Downloader/releases/download/v1.0/WebsiteDownloader.exe)
 
# How To Contribute:
 - Open Issue with any bug you noticed.
 - Let us know if We&You can add new features.
 - PR and changes you think it'd be an added value.

Thank you.

<p align="center">
<img src="https://user-images.githubusercontent.com/26596347/136268899-0096141d-8b68-4179-9af9-be24dae9c44e.png" alt="drawing" width="100"/>
</p>
 
